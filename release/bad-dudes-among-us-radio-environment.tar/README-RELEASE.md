# Bad Dudes Among Us Radio Environment - v1.0 

## Installation (Windows)
* Close Teamspeak
* Double click install.bat 
* Start Teamspeak
* Enable the Plugin